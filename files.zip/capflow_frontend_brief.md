# CapFlow — Frontend Engineering Brief
## Capital Pressure Monitor · Production Build Specification

---

## 1. PROJECT OVERVIEW

CapFlow is a capital flow monitoring dashboard for a single power user (not a public product). It visualises cross-asset capital pressure scores derived from a Python backend that combines price momentum, volume conviction, relative strength, and CFTC COT futures positioning data across 15 global instruments.

The frontend is the sole interface to the model. It must feel like a Bloomberg terminal crossed with a well-designed dark-mode analytics tool — dense with information but readable at a glance. No decorative elements. Every pixel earns its place.

**Stack:** Next.js 14 (App Router), TypeScript, Tailwind CSS, D3.js v7, shadcn/ui optional.

**Deployment:** Vercel. Backend is a separate FastAPI service on Railway.

---

## 2. DESIGN SYSTEM

### 2.1 Colours
```css
--bg:      #07090c    /* page background */
--s1:      #0c1018    /* primary surface (header, panels) */
--s2:      #111720    /* secondary surface (regime bar, scrubber) */
--s3:      #172030    /* hover state, selected state */
--s4:      #1d2a3a    /* input tracks, empty bar backgrounds */
--b1:      rgba(255,255,255,0.055)  /* primary border */
--b2:      rgba(255,255,255,0.03)   /* subtle border */
--t1:      #c8d4e0    /* primary text */
--t2:      #5e7a90    /* secondary text */
--t3:      #2e4455    /* tertiary text / labels */
--in:      #10b981    /* inflow / positive (green) */
--out:     #ef4444    /* outflow / negative (red) */
--amb:     #f59e0b    /* amber — warnings, contrarian flags, historical mode */
--blu:     #3b82f6    /* volume layer accent */
--pur:     #a855f7    /* relative strength layer accent */
```

### 2.2 Typography
- **Primary:** `Azeret Mono` (Google Fonts) — monospaced, used for all data, labels, numbers, UI chrome
- **Secondary:** `DM Sans` — used sparingly for any longer explanatory text in the breakdown panel
- Never use system fonts, Inter, or Roboto

### 2.3 Spacing & Borders
- 1px gaps between grid sections filled with `--b1` colour (creates hairline separators)
- Panel padding: 13–18px horizontal, 9–11px vertical
- All borders: 1px solid `--b1`
- Border radius: 2px maximum — this is a terminal, not a consumer app

### 2.4 Grain Overlay
Apply a subtle noise texture over the entire page via a fixed pseudo-element:
```css
body::after {
  content: '';
  position: fixed; inset: 0; pointer-events: none; z-index: 998;
  background: url("data:image/svg+xml,...fractalNoise...");
  opacity: 0.4;
}
```
Use an SVG feTurbulence filter with baseFrequency 0.85, numOctaves 4. This adds depth and prevents the dark surfaces from looking flat.

### 2.5 Motion
- Tile colour transitions: 150ms ease
- Bar fills: 400–600ms ease (layer breakdown bars animate on mount)
- Breakdown panel content: staggered fadeUp animation, 25ms delays between elements
- Scrubber fill: 150ms linear
- No bounce, no spring — all easing is ease or ease-out

---

## 3. LAYOUT

The app is a single-screen grid with no scrolling at the page level. Individual panels scroll internally.

```
grid-template-rows:    44px   /* header */
                       30px   /* regime bar */
                       34px   /* view switcher */
                       1fr    /* main content area */
                       58px;  /* time scrubber */

grid-template-columns: 1fr 340px;
```

All rows except the main content row are `grid-column: 1 / -1` (full width).

---

## 4. COMPONENTS

### 4.1 Header (row 1)

Three sections: left (logo), centre (window selector), right (market stats).

**Logo:**
- Text: `CAPFLOW` — 12px, font-weight 700, letter-spacing 6px
- Separator: 1px vertical line, 14px tall
- Subtitle: `CAPITAL PRESSURE MONITOR` — 8px, `--t3`, letter-spacing 2.5px

**Window selector:** Five buttons — `1W | 1M | 3M | 6M | 1Y`
- Font: Azeret Mono, 9px, letter-spacing 2px
- Default: transparent bg, `--t3` text, transparent border
- Hover: `--t2` text, `--b1` border
- Active: `--t1` text, `--b1` border, `--s3` background
- Active state is controlled by the API — changing window triggers a fresh fetch and re-render

**Market stats (right):** Four stat blocks, right-aligned
```
VIX     DXY     FED FUNDS     AS OF
22.4    104.2   5.25–5.50%    05 MAR 2026
```
- Label: 7px, `--t3`, letter-spacing 2px
- Value: 11px, `--t1` (with `.up` = `--in` and `.dn` = `--out` colour modifiers)
- These update when the scrubber changes snapshot (historical mode shows historical values)

---

### 4.2 Regime Bar (row 2)

A horizontal strip of labelled data points separated by 1px borders. Background `--s2`.

Items (left to right):
1. `• REGIME` + pill badge (e.g. `COMMODITY / USD ROTATION`)
2. `RISK POSTURE` + value (e.g. `SELECTIVE`)
3. `FED STANCE` + value (e.g. `RESTRICTIVE`)
4. `TOP INFLOW` + ticker and score
5. `TOP OUTFLOW` + ticker and score
6. `WINDOW` + current window (flex: 1, fills remaining space, no right border)

**Regime pill badge variants:**
```
.com  — amber     (commodity/rotation regimes)
.roff — red       (risk-off, crisis)
.ron  — green     (risk-on)
.neu  — grey/t2   (neutral, cash hoarding)
```
Each has border + background at 30% and 6% opacity respectively.

**Pulse dot:** 5px circle, `--in` colour, CSS animation pulsing opacity 1→0.25→1 over 2s. Sits before the REGIME label. In historical mode: colour changes to `--amb`, animation stops.

**All values update when scrubber changes.** The regime is determined by the snapshot data, not computed client-side.

---

### 4.3 View Switcher (row 3)

Five tab buttons with a coloured bottom-border active indicator. Background `--s1`.

```
● COMPOSITE    ● L1 · MOMENTUM    ● L2 · VOLUME    ● L3 · RELATIVE    ● L4 · COT
```

Each button has a 6px coloured dot (the `●`) before the label:
- COMPOSITE: `--t2` (grey)
- MOMENTUM: `--in` (green)
- VOLUME: `--blu` (blue)
- RELATIVE: `--pur` (purple)
- COT: `--amb` (amber)

Active state: button text colour matches its dot colour, 2px bottom border in same colour.

Right side of switcher: a description string that updates with active view. Examples:
- Composite: `ALL FOUR LAYERS · COMPOSITE PRESSURE SCORE`
- Momentum: `L1 · PRICE RETURN NORMALISED TO INSTRUMENT HISTORY`
- Volume: `L2 · CURRENT VOLUME VS 30-DAY AVERAGE`
- Relative: `L3 · PERFORMANCE VS UNIVERSE AVERAGE`
- COT: `L4 · SPECULATIVE FUTURES POSITIONING Z-SCORE (52W)`

**Changing view re-renders the treemap and ranked list with the new layer's values.** Breakdown panel also updates if a ticker is selected.

---

### 4.4 Treemap Panel (main area, left column)

D3 treemap. Full height and width of its grid cell.

**Tile sizes:** Fixed per-instrument weights reflecting global market significance (not score-based). These never change regardless of view or snapshot:
```javascript
const SIZES = {
  SPY:1000, TLT:800, GLD:600, EEM:500, VGK:450, EMB:380,
  GBTC:350, EMLC:320, USO:320, DJP:300, UUP:280, FXY:250,
  BIL:230, SHV:220, EZA:200
}
```

**Tile colour:** Driven by the active view's value for each instrument.
- Colour scale: deep red (−10) → dark neutral (0) → deep green (+10)
- Volume view: deep blue → dark neutral → light blue
- Relative view: deep red → dark neutral → deep purple
- COT view: deep red → dark neutral → amber
- Midpoint colour: `rgb(23, 35, 50)` (dark teal, not pure black)

**Tile opacity (model view only):** Confidence-driven
- HIGH: 1.0
- MEDIUM: 0.72
- LOW: 0.42

**Tile content (rendered only if tile is large enough):**
- Ticker symbol: centred, font-weight 700, scales with tile width (max 13px)
- Score/value: centred below ticker, 65% opacity white, scales with tile width (max 10px)
- Confidence dot: 3px circle, top-right corner. GREEN=HIGH, AMBER=MEDIUM, DARK=LOW. Model view only.
- Contrarian warning (⚠): bottom-left, 11px, amber at 85% opacity. Model view only, only when contrarian=true.
- COT "NO COT" label: bottom-centre, 7px, 20% opacity white. COT view only, only when no futures data.

**Interactions:**
- Hover: tile opacity drops to 0.75, tooltip appears
- Click: selects ticker, switches right panel to Breakdown tab, populates breakdown

**Tooltip:** Fixed-position div following cursor. Dark background, `--b1` border, box-shadow. Contains:
- Ticker + full label as header (coloured by direction)
- Rows of label:value pairs for the active view
- In model view: direction, confidence, all three layer values, COT z-score
- Contrarian warning row in amber if applicable

**Legend (bottom-right of treemap panel):**
Small box showing the colour gradient label and a canvas-rendered gradient bar. Updates with view.

---

### 4.5 Right Panel (main area, right column)

340px wide. Two tabs: RANKED and BREAKDOWN.

**Tab bar:** Two equal-width tabs with bottom-border active indicator.

#### RANKED TAB

Scrollable list of all instruments sorted by the active view's value (descending).

Each row:
```
[TICKER]  [Label              ] [████░░░░░░░] [+10.00] [HIGH] [⚠]
```
- Ticker: 9px, font-weight 600, 36px wide, coloured by direction
- Label: 7.5px, `--t3`, 130px wide, truncated with ellipsis
- Bar: flex-fill, 2px height, filled proportionally to max absolute value in current universe
- Score: 9px, font-weight 600, 40px, right-aligned, coloured by direction
- Confidence badge: 6.5px, letter-spacing 1px, 30px — HIGH/MEDIUM/LOW in decreasing opacity
- Contrarian warning (⚠): amber, 10px, only in model view

Bar opacity follows confidence in model view. Colour follows view:
- Model/Momentum/Relative: green (inflow) or red (outflow)
- Volume: blue (above avg) or red (below avg)
- COT: amber (net long) or red (net short)

Click row → selects instrument → switches to Breakdown tab.
Selected row background: `--s3`.

#### BREAKDOWN TAB

Shown when a ticker is clicked. Structured decomposition of the selected instrument's score in the current snapshot.

**Header block:**
- Ticker symbol: 16px, font-weight 700, letter-spacing 2px
- Full label: 8px, `--t3`
- Score: 26px, font-weight 700, coloured by direction (`--in` or `--out`)
- Direction badge: small pill — `INFLOW` (green border/bg) or `OUTFLOW` (red border/bg)
- Confidence: 7.5px, `--t3`, letter-spacing 2px, e.g. `HIGH CONFIDENCE`

**Divider** (1px horizontal rule)

**Layer decomposition section:**

Three layer rows (L1 Momentum, L2 Volume, L3 Relative). Each:
- Top row: layer name (left) | normalised value (centre, coloured) | weight range (right, dim)
- Bar track: 3px height, centred zero-line. Fill extends left (negative) or right (positive) from centre
- Bar colour: green if positive, red if negative, dark grey if near zero (|val| < 0.05)
- Values shown to 3 decimal places

**Divider**

**COT Positioning section:**

Label: `L4 · POSITIONING (COT)`

Info block (dark background, `--b1` border):
- Z-SCORE (52W): value (amber if |z|≥1.5, red if |z|≥2.0)
- STATUS: `NEUTRAL` / `SLIGHTLY STRETCHED` / `MODERATELY CROWDED` / `EXTREMELY CROWDED` / `No COT data`
- MODIFIER: e.g. `0.75× (discounted)` or `1.00× (no discount)`

**Contrarian Flag** (only shown when contrarian=true):

Prominent card with left amber border stripe (3px), amber border, amber tinted background.

Structure:
```
┌─── ⚠  CONTRARIAN POSITION ──────────────────────────┐
│         COT POSITIONING OPPOSES PRESSURE SIGNAL      │
├──────────────────────────────────────────────────────┤
│  [Explanatory paragraph — different copy for         │
│   inflow vs outflow contrarian situations]           │
├──────────────┬──────────────┬──────────────┬────────┤
│ SIGNAL       │ COT Z        │ CONFLICT     │ RISK   │
│ INFLOW       │ −0.50        │ Price↑/Short │ MOD.   │
└──────────────┴──────────────┴──────────────┴────────┘
```

**Inflow contrarian copy:** "Inflow pressure detected but COT shows funds are net **short** this instrument (z=X). Price is rising without speculative futures participation — may indicate physical or ETF demand rather than leveraged speculation."

**Outflow contrarian copy:** "Outflow pressure detected but COT shows funds are net **long** this instrument (z=X). Crowded longs are being held while price falls — elevated forced unwind risk if selling accelerates."

Risk label colours: ELEVATED = `--out`, MODERATE = `--amb`.

All breakdown content animates in on mount with staggered fadeUp (25ms delay increments).

---

### 4.6 Time Scrubber (row 5, full width)

58px tall bar. Background `--s2`. This is the historical replay control.

**Layout:**
```
[05 MAR 2026 · LATEST SNAPSHOT]              [● LIVE]
[━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━]
[COVID CRASH · MAR 2020]  [PEAK RATE HIKE]  [AI RALLY]  [LIVE · MAR 2026]
```

**Top row:** Date label (left) + mode indicator (right)
- Date: 10px, font-weight 600, letter-spacing 1px — shows the date of current snapshot
- Snapshot name: 7.5px, `--t3`, prefixed with ` · ` — e.g. `· COVID CRASH — 20 MAR 2020`
- Mode: pulse dot + `LIVE` or `HISTORICAL` text — dot is green+pulsing when live, amber+static when historical

**Track:**
- 2px height track line in `--s4`
- Fill: gradient from `--t3` to `--t2` extending from left to current position
- Four marker dots positioned at 0%, 33.3%, 66.6%, 100% of track width

**Marker dots:**
- 8px circles, `--s4` fill, `--t3` border by default
- Hover: `--amb` fill, `--amb` border, subtle glow
- Active (current snapshot): `--amb` fill, `--amb` border, glow
- Small label above each dot (positioned at `bottom: 14px`): snapshot name, 6.5px, `--t3` → `--amb` on hover/active

**Range input:** `<input type="range" min="0" max="3" step="1">` overlaid at full opacity 0 on top of the visual track, capturing all mouse/touch events. The visual elements are purely decorative, driven by the input's value.

**Bottom row:** Text labels at each snap position — `COVID CRASH · MAR 2020`, `PEAK RATE HIKE · OCT 2022`, `AI RALLY · NOV 2023`, `LIVE · MAR 2026`

**On snapshot change, the following all update simultaneously:**
- Treemap (recoloured with new snapshot data)
- Ranked list (re-sorted, new values)
- Regime bar (pill, risk posture, fed stance, top inflow/outflow)
- Header stats (VIX, DXY, Fed Funds rate, As Of date)
- Breakdown panel if a ticker is selected (or shows "NO DATA FOR THIS TICKER IN SELECTED PERIOD" if instrument didn't exist at that date — relevant for GBTC/IBIT in pre-2020 snapshots)
- Scrubber fill width and active marker dot

---

## 5. API CONTRACT

The frontend consumes a single primary endpoint:

```
GET /snapshot?window=3M&as_of=2026-03-05
```

**Query params:**
- `window`: `1W | 1M | 3M | 6M | 1Y` (default: `3M`)
- `as_of`: ISO date string (default: today / most recent trading day)

**Response shape:**
```typescript
interface SnapshotResponse {
  generated_at: string;          // ISO datetime
  window:       string;
  as_of:        string;          // actual trading date used
  regime: {
    label:       string;         // e.g. "COMMODITY / USD ROTATION"
    pill_class:  'com'|'roff'|'ron'|'neu';
    risk:        string;
    risk_class:  'bull'|'bear'|'warn';
    fed_stance:  string;
    fed_class:   'bull'|'bear'|'warn';
    vix:         number;
    dxy:         number;
    fed_rate:    string;         // e.g. "5.25–5.50%"
  };
  scores: InstrumentScore[];
}

interface InstrumentScore {
  ticker:              string;
  label:               string;   // e.g. "Crude Oil (USO)"
  asset_class:         string;   // e.g. "Commodities"
  pressure_score:      number;   // −10 to +10
  direction:           'inflow' | 'outflow';
  confidence:          'HIGH' | 'MEDIUM' | 'LOW';
  momentum_norm:       number;   // −1 to +1
  volume_norm:         number;   // −1 to +1
  relative_norm:       number;   // −1 to +1
  positioning_z:       number | null;
  positioning_mod:     number;
  contrarian_position: boolean;
}
```

**Caching strategy:**
- Backend caches daily (markets close once a day — no need for sub-daily refresh)
- First request of the day fetches and computes (~10–15s), subsequent requests serve from cache (<200ms)
- Frontend shows a loading skeleton on first load, then caches the response in React state
- Window changes and date changes trigger new fetches (or serve from a client-side cache keyed by `{window}_{as_of}`)

**Date handling on the frontend:**
The scrubber currently has four hard-coded snapshot positions. In the full implementation, this becomes a continuous date slider. The range input maps to a `date_index` array fetched from:

```
GET /date-index
→ { dates: string[] }   // all valid trading Fridays in data range
```

The frontend maps slider position (0 to dates.length-1) to a date string, sends that as `as_of` to `/snapshot`.

---

## 6. STATE MANAGEMENT

Use React state (no external state library needed at this scale).

```typescript
// Global state
const [window, setWindow]         = useState<WindowLabel>('3M');
const [asOf, setAsOf]             = useState<string | null>(null); // null = latest
const [currentView, setView]      = useState<ViewKey>('model');
const [selectedTicker, setTicker] = useState<string | null>(null);
const [snapshot, setSnapshot]     = useState<SnapshotResponse | null>(null);
const [isLoading, setLoading]     = useState(true);
const [isHistorical, setHistorical] = useState(false);
```

Cache fetched snapshots in a `useRef` map:
```typescript
const cache = useRef<Map<string, SnapshotResponse>>(new Map());
// key: `${window}_${asOf ?? 'latest'}`
```

---

## 7. TREEMAP IMPLEMENTATION NOTES

Use D3 treemap directly in a React component with a `useEffect` that re-renders when `snapshot`, `currentView`, or container dimensions change.

```typescript
// Tile sizing: fixed weights, never change
const TILE_SIZES: Record<string, number> = {
  SPY:1000, TLT:800, GLD:600, EEM:500, VGK:450, EMB:380,
  GBTC:350, EMLC:320, USO:320, DJP:300, UUP:280, FXY:250,
  BIL:230, SHV:220, EZA:200
};

// Get display value based on current view
function getViewValue(score: InstrumentScore, view: ViewKey): number | null {
  switch (view) {
    case 'model':    return score.pressure_score;
    case 'momentum': return score.momentum_norm * 10;
    case 'volume':   return score.volume_norm * 10;
    case 'relative': return score.relative_norm * 10;
    case 'cot':      return score.positioning_z !== null
                       ? Math.max(-10, Math.min(10, score.positioning_z * 4))
                       : null;
  }
}
```

Use a ResizeObserver on the treemap container to re-render on window resize.

D3 treemap padding: 2px inner, 2px outer. Border radius 2px on rects.

SVG text elements: only render if tile width > 32px and height > 22px. Scale font size with tile width, clamped to 13px max for ticker, 10px max for value.

---

## 8. KEYBOARD & ACCESSIBILITY

- Arrow keys on the scrubber input navigate between snapshots
- Escape deselects the selected ticker and returns ranked list to default state
- Tab navigation through view switcher buttons and window buttons
- All interactive elements have visible focus styles (2px `--t2` outline, 2px offset)

---

## 9. LOADING STATES

**Initial load:** Show skeleton tiles in the treemap (dark rectangles at correct D3-computed positions, pulsing opacity animation). Ranked list shows 15 skeleton rows.

**Snapshot transition:** Tiles fade to 50% opacity during fetch, then cross-fade to new colours. Ranked list items slide out and in. Duration: 300ms.

**Error state:** If API is unreachable, show a centred message in the treemap panel:
```
API UNAVAILABLE
Last updated: [cached date if available]
[RETRY] button
```

---

## 10. RESPONSIVE BEHAVIOUR

This dashboard is designed for desktop only (minimum 1280px width). On smaller screens display a message:
```
CAPFLOW requires a minimum screen width of 1280px.
Please open on a desktop browser.
```

No mobile layout needed.

---

## 11. INSTRUMENT REFERENCE

The 15 instruments in the current universe:

| Ticker | Label                    | Asset Class   | Has COT |
|--------|--------------------------|---------------|---------|
| USO    | Crude Oil                | Commodities   | Yes     |
| GLD    | Gold                     | Commodities   | Yes     |
| DJP    | Broad Commodities        | Commodities   | Yes     |
| EZA    | South African Equities   | Equities      | Yes (ZAR proxy) |
| VGK    | European Equities        | Equities      | Yes     |
| EEM    | Emerging Markets         | Equities      | Yes     |
| EMLC   | EM Local Currency Bonds  | Bonds         | No      |
| EMB    | EM USD Bonds             | Bonds         | No      |
| SPY    | US Equities              | Equities      | Yes     |
| UUP    | US Dollar                | FX            | Yes     |
| BIL    | T-Bills 1-3M             | Money Market  | No      |
| FXY    | Japanese Yen             | FX            | Yes     |
| TLT    | US Long Bonds            | Bonds         | Yes     |
| SHV    | US Short Bonds           | Money Market  | No      |
| GBTC   | Bitcoin                  | Crypto        | Yes     |

---

## 12. FILE STRUCTURE

```
/app
  /page.tsx              — root layout, data fetching
  /components
    Header.tsx            — logo, window selector, market stats
    RegimeBar.tsx         — regime pill, risk posture, fed stance, top flows
    ViewSwitcher.tsx      — five layer view buttons
    Treemap.tsx           — D3 treemap, tile rendering, tooltip
    RightPanel.tsx        — tab container
    RankedList.tsx        — sorted instrument list
    Breakdown.tsx         — instrument detail decomposition
    ContrarianFlag.tsx    — amber warning card
    TimeScrubber.tsx      — historical replay control
    Tooltip.tsx           — floating tooltip (portal)
  /hooks
    useSnapshot.ts        — fetching, caching, loading state
    useDateIndex.ts       — available trading dates
    useTreemap.ts         — D3 layout computation
  /types
    index.ts              — all TypeScript interfaces
  /lib
    colours.ts            — colour scale functions
    format.ts             — number formatting utilities
    viewConfig.ts         — per-view metadata (labels, colours, descriptions)
```

---

## 13. WORKING MOCKUP

A complete working HTML mockup of the dashboard exists with all four historical snapshots hard-coded and all interactions functional. The AI implementing this brief should use the mockup as the visual reference — the goal is to reproduce the exact aesthetic and layout in Next.js/React, replacing the hard-coded data with live API calls.

The mockup demonstrates:
- Correct grid proportions and spacing
- D3 treemap tile sizing and colour behaviour
- Time scrubber interactions and snapshot transitions
- View switcher recolouring treemap and ranked list
- Breakdown panel with layer bars and contrarian flag
- All regime bar transitions between snapshots

**Treat the mockup as the source of truth for visual design. Treat this document as the source of truth for implementation architecture.**
